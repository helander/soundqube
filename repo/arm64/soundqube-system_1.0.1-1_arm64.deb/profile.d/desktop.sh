
if [ "$TERM" == "linux" ];then
  touch linuxterm
  export DISPLAY=:56
  Xvfb :56 &
  x11vnc -N -forever &
  startxfce4 &
  sleep infinity
fi
